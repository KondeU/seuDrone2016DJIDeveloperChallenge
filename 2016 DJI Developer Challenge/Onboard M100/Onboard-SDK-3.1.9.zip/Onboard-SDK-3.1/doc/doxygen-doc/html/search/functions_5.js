var searchData=
[
  ['getacceleration',['getAcceleration',['../classDJI_1_1onboardSDK_1_1Flight.html#a468a431f738f794776f19170735a1637',1,'DJI::onboardSDK::Flight']]],
  ['getaccountdata',['getAccountData',['../classDJI_1_1onboardSDK_1_1CoreAPI.html#ae35f58e3a1293bc5615502055e94864a',1,'DJI::onboardSDK::CoreAPI']]],
  ['getapi',['getApi',['../classDJI_1_1onboardSDK_1_1Camera.html#a3b6073643c2afe2c5502789f0fb74b70',1,'DJI::onboardSDK::Camera::getApi()'],['../classDJI_1_1onboardSDK_1_1Flight.html#a26f4cea3ae5a5bae1c63a67a4db24c2f',1,'DJI::onboardSDK::Flight::getApi()']]],
  ['getbatterycapacity',['getBatteryCapacity',['../classDJI_1_1onboardSDK_1_1CoreAPI.html#accb169d18e0ce644b0adf7284483cc41',1,'DJI::onboardSDK::CoreAPI']]],
  ['getbroadcastdata',['getBroadcastData',['../classDJI_1_1onboardSDK_1_1CoreAPI.html#a6e28d9d1bf933ee5ccfab6ec8891e16e',1,'DJI::onboardSDK::CoreAPI']]],
  ['getdriver',['getDriver',['../classDJI_1_1onboardSDK_1_1CoreAPI.html#ab06228e965457f85ac8eebc7669a09ef',1,'DJI::onboardSDK::CoreAPI']]],
  ['getdroneversion',['getDroneVersion',['../classDJI_1_1onboardSDK_1_1CoreAPI.html#ad0af34b1556ba02f25daeaf0e91d61b3',1,'DJI::onboardSDK::CoreAPI::getDroneVersion(CallBack callback=0, UserData userData=0)'],['../classDJI_1_1onboardSDK_1_1CoreAPI.html#a94346c03fc72f0d9ca8a8709dad67f91',1,'DJI::onboardSDK::CoreAPI::getDroneVersion(int timeout)']]],
  ['getfilter',['getFilter',['../classDJI_1_1onboardSDK_1_1CoreAPI.html#ab7fa0d20a6e4bf39a43a1c8a4841667f',1,'DJI::onboardSDK::CoreAPI']]],
  ['getflightstatus',['getFlightStatus',['../classDJI_1_1onboardSDK_1_1CoreAPI.html#a83775b0cee8ef84d454ce6025edc1b62',1,'DJI::onboardSDK::CoreAPI']]],
  ['gethotpointdata',['getHotPointData',['../classDJI_1_1onboardSDK_1_1CoreAPI.html#a021fc52fda6637f3624ae14e1a96dc28',1,'DJI::onboardSDK::CoreAPI']]],
  ['getmagnet',['getMagnet',['../classDJI_1_1onboardSDK_1_1Flight.html#a23fbea760546876fbd6b6af269deb1d1',1,'DJI::onboardSDK::Flight']]],
  ['getobtaincontrolmobilecmd',['getObtainControlMobileCMD',['../classDJI_1_1onboardSDK_1_1CoreAPI.html#ad8fb88ea4af11dbec0e08dcff1be1709',1,'DJI::onboardSDK::CoreAPI']]],
  ['getquaternion',['getQuaternion',['../classDJI_1_1onboardSDK_1_1Flight.html#a63fcbf96eb69c5ffe7c1cfae237ec5de',1,'DJI::onboardSDK::Flight']]],
  ['getrcdata',['getRCData',['../classDJI_1_1onboardSDK_1_1VirtualRC.html#ab2ff6d77cdc0da443c5ae27736c06501',1,'DJI::onboardSDK::VirtualRC']]],
  ['getsdkversion',['getSDKVersion',['../classDJI_1_1onboardSDK_1_1CoreAPI.html#aba01d2d5cc5fa9b13198312d1cc8fd5f',1,'DJI::onboardSDK::CoreAPI']]],
  ['gettime',['getTime',['../classDJI_1_1onboardSDK_1_1CoreAPI.html#af90c4551b82a3926d9ed5316b4084bb3',1,'DJI::onboardSDK::CoreAPI']]],
  ['getvrcdata',['getVRCData',['../classDJI_1_1onboardSDK_1_1VirtualRC.html#adde3376c294c532e5fbea7ec81bef009',1,'DJI::onboardSDK::VirtualRC']]],
  ['getwaypointdata',['getWayPointData',['../classDJI_1_1onboardSDK_1_1CoreAPI.html#ab5aa9af0ebe66a85ef24630284a1699d',1,'DJI::onboardSDK::CoreAPI']]],
  ['getyawrate',['getYawRate',['../classDJI_1_1onboardSDK_1_1Flight.html#a097f8e5f55b1de4bc62754b061221bd5',1,'DJI::onboardSDK::Flight']]]
];
